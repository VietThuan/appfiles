﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.Global.Dependency.App
{
    //Singleton
    public class EmployeeRepository
    {
        private static EmployeeRepository? instance;
        protected EmployeeRepository() { }
        public static EmployeeRepository GetInstance()
        {
            return instance ?? (instance = new EmployeeRepository());
        }

        public bool CreateEmployeeById(Guid id, string name)
        {
            Console.WriteLine("Connect DB");
            Console.WriteLine($"Create Employee by Id: {id} name: {name}");
            return true;
        }
    }
}
