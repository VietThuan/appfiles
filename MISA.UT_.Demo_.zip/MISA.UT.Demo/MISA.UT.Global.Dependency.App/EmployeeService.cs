﻿using System;

namespace MISA.UT.Global.Dependency.App
{
    public class EmployeeService
    {
        /// <summary>
        /// Method sử dụng đối tượng EmployeeRepository
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public Guid? CreateEmployee(string name)
        {
            var empRepo = EmployeeRepository.GetInstance();
            var empId = Guid.NewGuid();
            if (empRepo.CreateEmployeeById(empId, name))
            {
                return empId;
            }
            return null;
        }

        /// <summary>
        /// Method sử dụng đối tượng EmployeeRepositoryExI (Sau khi refactor)
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public Guid? CreateEmployeeExI(string name)
        {
            var empRepo = EmployeeRepositoryExI.GetInstance();
            var empId = Guid.NewGuid();
            //TODO Bỏ comment ở đây để test case Dev sử dụng hàm thay đổi Instance trong code product
            //EmployeeRepositoryExI.SetTestInstance(empRepo);
            if (empRepo.CreateEmployeeById(empId, name))
            {
                return empId;
            }
            return null;
        }

    }
}
