﻿using System;

namespace MISA.UT.Global.Dependency.App
{
    /*
     * Sử dụng cho bài thực hành số 6 mục biến toàn cục.
     * Thực hành refactor code để stub, mock được các hàm static, khử phụ thuộc toàn cục.
     * 1. Chuyển class EmployeeRepository về mẫu Singleton => đặt tên lớp là EmployeeRepositoryExI (trong thực tế thì sửa trực tiếp lớp EmployeeRepository)
     * 1.1 Set private contructor
     * 2. Chuyển các hàm static thành non static.
     * 3. Extract interface class này => IEmployeeRepository
     * 3.1 Khai báo property: private static IEmployeeRepository? instance;
     * 3.2 Viết method trả về instanse => phục vụ mục đích khởi tạo 1 lần duy nhất.
     * 4. Thêm hàm setinstance(IEmployeeRepository instance) => cho phép thay đổi instance trong quá hình hệ thống chạy.
     * 5.1 Set attribute Obsolete cho method setinstance  với param error = true => không cho phép sử dụng hàm này => biên dịch sẽ bị lỗi.
     * 6. Thực hiện cập nhật EmployeeService sử dụng đối tượng EmployeeRepositoryExI => test case sử dụng hàm setinstance => build lỗi.
     * 7. Thực hiện tạo project test MISA.UT.Global.Dependency.App2.Test (tương ứng với project MISA.UT.Global.Dependency.App.Test)
     * 7.1 Add project MISA.UT.Global.Dependency.App.App => Add reference project MISA.UT.Global.Dependency.App, add nuget 
     * 7.1 Tạo class test EmployeeServiceTest => để test class EmployeeService
     */
    public class Program
    {
        static void Main(string[] args)
        {
            var employeeService = new EmployeeService();
            employeeService.CreateEmployee("Nguyen Van A");
            Console.WriteLine("----------------");
            employeeService.CreateEmployeeExI("Nguyen Van B");
            Console.ReadLine();
        }
    }
}
