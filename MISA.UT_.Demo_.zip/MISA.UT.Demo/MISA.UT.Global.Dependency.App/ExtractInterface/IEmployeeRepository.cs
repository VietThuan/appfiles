﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.Global.Dependency.App
{
    public interface IEmployeeRepository
    {
        public bool CreateEmployeeById(Guid id, string name);
    }
}
