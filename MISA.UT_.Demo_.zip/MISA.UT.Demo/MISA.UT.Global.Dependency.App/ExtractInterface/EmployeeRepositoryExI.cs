﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.Global.Dependency.App
{
    /// <summary>
    /// Đối tượng sau khi refactor class EmployeeRepository
    /// Về logic thì 2 đối tượng này là 1 => tạo ra lớp riêng để dễ hình dung
    /// Đôi ExI viết tắt của extract interface
    /// </summary>
    public class EmployeeRepositoryExI : IEmployeeRepository
    {
        private static IEmployeeRepository? instance;

        private EmployeeRepositoryExI() { }


        /// <summary>
        /// Không cho phép Dev sử dụng hàm này trong code product.
        /// Chỉ cho phép sử dụng ở project unit test.
        /// </summary>
        /// <param name="newInstance"></param>
        [Obsolete("This method is only test", true)]

        public static void SetTestInstance(IEmployeeRepository newInstance)
        {
            instance = newInstance;
        }

        public static IEmployeeRepository GetInstance()
        {
            return instance ?? (instance = new EmployeeRepositoryExI());
        }
        public bool CreateEmployeeById(Guid id, string name)
        {
            Console.WriteLine("[ExtractInterface] Connect DB");
            Console.WriteLine($"[ExtractInterface] Create Employee by Id: {id} name: {name}");
            return true;
        }
    }
}
