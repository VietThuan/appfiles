﻿
namespace MISA.UT.BD.App.Test
{
    public class StubFileManager : IFileExtensionManager
    {
        public bool WillBeValid = false;
        public bool IsValid(string fileName)
        {
            return WillBeValid;
        }
    }
}
