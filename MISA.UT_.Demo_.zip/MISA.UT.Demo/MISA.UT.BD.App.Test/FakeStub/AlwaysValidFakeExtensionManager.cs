﻿
namespace MISA.UT.BD.App.Test
{
    public class AlwaysValidFakeExtensionManager : IFileExtensionManager
    {
        public bool IsValid(string fileName)
        {
            return true;
        }
    }
}
