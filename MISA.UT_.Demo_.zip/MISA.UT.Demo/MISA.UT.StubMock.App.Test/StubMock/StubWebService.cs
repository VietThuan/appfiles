﻿using System;

namespace MISA.UT.StubMock.App.Test.StubMock
{
    public class StubWebService : IWebService
    {
        public Exception ToThrow { set; get; }
        public void LogError(string message)
        {
            if (ToThrow != null)
            {
                throw ToThrow;
            }
        }
    }
}
