﻿
namespace MISA.UT.StubMock.App.Test
{
    public class MockWebService : IWebService
    {
        public string? LastError { set; get; }
        public void LogError(string message)
        {
            LastError = message;
        }
    }
}
