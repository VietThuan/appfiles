﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.BD.App
{
    public interface IFileExtensionManager
    {
        bool IsValid(string fileName);
    }
}
