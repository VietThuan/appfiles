﻿using System;
using System.Configuration;

namespace MISA.UT.BD.App
{
    public class FileExtensionManagerBD : IFileExtensionManager
    {
        public bool IsValid(string fileName)
        {
            var extenstion = string.IsNullOrEmpty(ConfigurationManager.AppSettings["extensionsupport"]) ? ".SLF" : ConfigurationManager.AppSettings["ExtensionSupport"];
            if (!fileName.EndsWith(extenstion, StringComparison.CurrentCultureIgnoreCase))
            {
                return false;
            }
            return true;
        }
    }
}
