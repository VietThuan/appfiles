﻿using System;

namespace MISA.UT.BD.App
{
    /*
     * Sử dụng cho slide Break Dependency (Thực hành số 2)
     * Mục đích: Thành viên buổi đào tạo biết được từng bước refactor để khử phụ thuộc.
     * => Nên cho thành viên tạo project mới, sử dụng lớp LogAnalyzer và thực hành refactor như các bước bên dưới.
     * Kịch bản
     * 1. Chạy thử ứng dụng.
     * 2. Thực hiện refactor theo từng bước.
     * 3. Class LogAnalyzer là class gốc chưa được refactor
     * 4. Thực hiện refactor LogAnalyzer thành lớp LogAnalyzerPreBD
     * => Tạo lớp quản lý phụ thuộc => Mở comment phần PreBD
     * 5. Thực hiện refactor từ lớp LogAnalyzerPreBD thành lớp LogAnalyzerBD
     * Extract interface lớp quản lý phụ thuộc => Mở comment phần BD
     */

    /*
     * Sử dụng cho slide fake, stub (Thưc hành số 3)
     * Mục đích: Cho thành viên hiểu được fake, stub được sử dụng thế nào sau khi khử phục thuộc,
     * và những ưu điểm đạt được sau khi khử được phụ thuộc => Không phụ thuộc trong quá trình test + tốc độ tăng.
     * Tạo project MISA.UT.BD.App2.Test (Tương ứng với project MISA.UT.BD.App.Test)
     * 1. Thực hiện viết unit test trên class LogAnalyzerTests => để test class LogAnalyzer
     * 2. Thực hiện vết unit test sử dụng fake, stub cho class LogAnalyzerBD
     * 2.1. Viết class fake AlwaysValidFakeExtensionManager để phục vụ class LogAnalyzerBDFakeTests => để test class LogAnalyzerBD
     * 2.1. Viết class StubFileManager để phục vụ class LogAnalyzerBDStubTests => để test class LogAnalyzerBD
     * => chạy các unit test, so sánh thời gian chạy unit test giữa 1, 2.1 và 2.2 để thấy được hiệu quả về hiệu năng của việc loại bỏ phụ thuộc.
     */
    public class Program
    {
        static void Main(string[] args)
        {
            //Non BD
            var logAnalyzer = new LogAnalyzer();
            //Print false
            Console.WriteLine($"Non BreakDependency result: {logAnalyzer.IsValidLogFileName("test.log")}");
            //Print true
            Console.WriteLine($"Non BreakDependency result: {logAnalyzer.IsValidLogFileName("test.slf")}");

            ////PreBD
            //var logAnalyzerPreBD = new LogAnalyzerPreBD();
            ////Print false
            //Console.WriteLine($"Pre BreakDependency result: {logAnalyzerPreBD.IsValidLogFileName("test.log")}");
            ////Print true
            //Console.WriteLine($"Pre BreakDependency result: {logAnalyzerPreBD.IsValidLogFileName("test.slf")}");

            ////BD
            //var fileExtensionManager = new FileExtensionManagerBD();
            //var logAnalyzerBD = new LogAnalyzerBD(fileExtensionManager);
            ////Print false
            //Console.WriteLine($"BreakDependency result: {logAnalyzerBD.IsValidLogFileName("test.log")}");
            ////Print true
            //Console.WriteLine($"BreakDependency result: {logAnalyzerBD.IsValidLogFileName("test.slf")}");

            Console.ReadLine();
        }
    }
}
