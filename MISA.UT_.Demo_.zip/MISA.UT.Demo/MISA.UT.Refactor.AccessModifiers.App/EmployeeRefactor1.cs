﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.Refactor.AccessModifiers.App
{
    public class EmployeeRefactor1
    {
        private float WorkingDay;
        private float SalaryPerDay;
        protected internal virtual double CalculatorSalary()
        {
            WorkingDay = 22;
            SalaryPerDay = 500000;
            return WorkingDay * SalaryPerDay;
        }

        public double GetSalary()
        {
            return CalculatorSalary();
        }
    }
}
