﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.Refactor.AccessModifiers.App
{
    public class EmployeeRefactor2
    {
        private readonly ISalaryUtility salaryUtility;
        private float WorkingDay;
        private float SalaryPerDay;

        public EmployeeRefactor2(ISalaryUtility salaryUtility)
        {
            this.salaryUtility = salaryUtility;
        }

        private double CalculatorSalary()
        {
            return salaryUtility.CalculatorSalary(WorkingDay, SalaryPerDay);
        }

        public double GetSalary()
        {
            return CalculatorSalary();
        }
    }

    public class SalaryUtility : ISalaryUtility
    {
        public double CalculatorSalary(float workingday, float salaryperday)
        {
            return workingday * salaryperday;
        }
    }
}
