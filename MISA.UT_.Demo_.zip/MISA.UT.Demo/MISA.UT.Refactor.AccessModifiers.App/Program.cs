﻿using System;

namespace MISA.UT.Refactor.AccessModifiers.App
{
    /*
     * Sử dụng cho bài thực hành số 6 mục khử phụ thuộc hàm Private
     * Thực hành refactor code để cho phép có thể stub và mock được private method => class Employee
     * 1. Refactor
     * Cách 1: Chuyển private thành protected internal virtual => class EmployeeRefactor1
     * Cách 2: Thay thế thân hàm private thành các method có thể stub, mock được thông qua class khác => class EmployeeRefactor2
     * 2. Viết unit test
     * 2.1 Tạo project MISA.UT.Refactor.AccessModifiers.App2.Test (Tương ứng với project MISA.UT.Refactor.AccessModifiers.App.Test)
     * 2.2 Viết class test EmployeeRefactor1Test => để test class EmployeeRefactor1
     * 2.3 Viết class test EmployeeRefactor2Test => để test class EmployeeRefactor2
     */
    public class Program
    {
        static void Main(string[] args)
        {
            var employee = new Employee();
            Console.WriteLine($"Salary is: {employee.GetSalary()} VNĐ");
            Console.ReadLine();
        }
    }
}
