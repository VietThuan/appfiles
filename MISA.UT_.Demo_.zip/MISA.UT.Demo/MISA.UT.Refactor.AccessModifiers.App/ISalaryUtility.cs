﻿namespace MISA.UT.Refactor.AccessModifiers.App
{
    public interface ISalaryUtility
    {
        double CalculatorSalary(float workingday, float salaryperday);
    }
}