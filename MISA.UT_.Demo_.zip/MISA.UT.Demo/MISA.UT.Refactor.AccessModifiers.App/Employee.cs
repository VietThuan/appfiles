﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.Refactor.AccessModifiers.App
{
    public class Employee
    {
        private float WorkingDay;
        private float SalaryPerDay;
        private double CalculatorSalary()
        {
            WorkingDay = 22;
            SalaryPerDay = 500000;
            return WorkingDay * SalaryPerDay;
        }

        public double GetSalary()
        {
            return CalculatorSalary();
        }
    }
}
