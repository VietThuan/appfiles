﻿using NSubstitute;
using NUnit.Framework;
using System;

namespace MISA.UT.Global.Dependency.App.Test
{
    public class EmployeeServiceTest
    {
        private IEmployeeRepository fakeEmpRepo;

        [SetUp]
        public void Setup()
        {
            fakeEmpRepo = Substitute.For<IEmployeeRepository>();
            Type EmployeeRepositoryExIType = typeof(EmployeeRepositoryExI);
            var method = EmployeeRepositoryExIType.GetMethod("SetTestInstance");
            if (method == null)
            {
                Assert.Fail();
            }
            method.Invoke(null, new object[] { fakeEmpRepo });
        }

        [Test]
        public void CreateEmployeeExI_EmployeeName_Success()
        {
            var employeeService = new EmployeeService();
            fakeEmpRepo.CreateEmployeeById(Arg.Any<Guid>(), Arg.Any<string>()).Returns(true);

            var result = employeeService.CreateEmployeeExI("Nguyen Van A");

            Assert.IsTrue(result != null);
            fakeEmpRepo.Received(1).CreateEmployeeById(Arg.Any<Guid>(), "Nguyen Van A");
        }

        //[SetUp]
        //public void Setup()
        //{
        //    var fakeEmpRepo = new FakeEmployeeRepository();
        //    Type EmployeeRepositoryExIType = typeof(EmployeeRepositoryExI);
        //    var method = EmployeeRepositoryExIType.GetMethod("SetTestInstance");
        //    if (method == null)
        //    {
        //        Assert.Fail();
        //    }
        //    method.Invoke(null, new object[] { fakeEmpRepo });
        //}

        //[Test]
        //public void CreateEmployeeExI_EmployeeName_Success()
        //{
        //    var employeeService = new EmployeeService();

        //    var result = employeeService.CreateEmployeeExI("Nguyen Van A");

        //    Assert.IsTrue(result != Guid.Empty);
        //}



    }
}
