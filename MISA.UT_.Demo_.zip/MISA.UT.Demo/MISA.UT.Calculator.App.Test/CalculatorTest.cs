﻿using NUnit.Framework;

namespace MISA.UT.Calculator.App.Test
{
    public class CalculatorTest
    {
        private Calculator _cal;

        [SetUp]
        public void Setup()
        {
            _cal = new Calculator();
        }

        [Test]
        public void Add_OnePlusOne_EqualTwo()
        {
            Assert.AreEqual(2, _cal.Add(1, 1));
        }
                    
        [Test]
        public void Division_FourByTwoDivision_EqualTwo()
        {
            Assert.AreEqual(2, _cal.Division(4, 2));
        }

        //TODO Mở comment để refactor hàm Division
        //[Test]
        //public void Division_DivisionByZero_ReturnNull()
        //{
        //    Assert.IsNull(_cal.Division(1, 0));
        //}

        //[Test]
        //public void Division_ThreeByTwoDivision_EqualOnePointFive()
        //{
        //    Assert.AreEqual(1.5, _cal.Division(3, 2));
        //}

        [Test]
        public void Division_DoubleTwo_EqualFour()
        {
            var inputValue = 2;
            _cal.DoubeValue(ref inputValue);
            Assert.AreEqual(4, inputValue);
        }
    }
}