﻿using System;

namespace MISA.UT.StubMock.App
{
    public class LogAnalyzerStubMock
    {
        private IWebService _websSrvice;
        private IEmailService _emailService;
        public LogAnalyzerStubMock(IWebService websSrvice, IEmailService emailService)
        {
            this._websSrvice = websSrvice;
            this._emailService = emailService;
        }
        public void Analyze(string fileName)
        {
            if (fileName.Length < 8)
            {
                try
                {
                    //Stub: Chay den day la phai throw exception
                    _websSrvice.LogError("Filename too short:" + fileName);
                }
                catch (Exception e)
                {
                    //Mock: Kiểm tra đầu vào xem có đúng giá trị mong muốn hay không?
                    _emailService.SendEmail("nguyenvana@gmail.com", "can’t log", e.Message);
                }
            }
        }
    }
}
