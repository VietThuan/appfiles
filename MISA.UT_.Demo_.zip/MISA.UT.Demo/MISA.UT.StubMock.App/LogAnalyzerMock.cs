﻿
namespace MISA.UT.StubMock.App
{
    public class LogAnalyzerMock
    {
        private IWebService _websSrvice;
        public bool WasLastFileNameValid { get; set; }
        public LogAnalyzerMock(IWebService websSrvice)
        {
            this._websSrvice = websSrvice;
        }
        public void Analyze(string fileName)
        {
            WasLastFileNameValid = false;
            if (fileName.Length < 8)
            {
                //Mock: Kiểm tra đầu vào xem có đúng giá trị mong muốn hay không?
                //Ví dụ: filename là log.log thì phải kiêm tra param của method LogError có phải là:
                // Filename too short: log.log
                _websSrvice.LogError("Filename too short:"
                + fileName);
                return;
            }
            WasLastFileNameValid = true;
        }
    }
}
