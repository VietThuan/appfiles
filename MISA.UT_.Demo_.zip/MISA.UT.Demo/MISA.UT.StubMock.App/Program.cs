﻿using System;

namespace MISA.UT.StubMock.App
{
    /*
     * Sử dụng cho slide Mock (Thực hành số 4)
     * Mục đích: Giúp cho thành viên buổi đào tạo phân biệt được Stub và Mock
     * bằng cách triển khai các đối tượng stub và mock manual và sử dụng framework NSubstitute.
     * 1. Cho thành viên chạy thử ứng dụng
     * 2. Đọc hiểu 2 class LogAnalyzerMock và LogAnalyzerStubMock => giải thích việc stub và mock sẽ sử dụng trong các trường hợp nào,
     * chúng hoạt động thế nào (kết hợp với slide)
     * 3. Yêu cầu thành viên tạo project test MISA.UT.StubMock.App2.Test (Tương ứng với project MISA.UT.StubMock.App.Test)
     * 3.1 Thực hiện viết class LogAnalyzerMockTest => Test class LogAnalyzerMock
     * 3.2 Thực hiện viết class LogAnalyzerStubMockTest => Test class LogAnalyzerStubMock => Kết hợp cả stub lẫn mock.
     */
    /*
     * Sử dụng cho slide NSubstitute (Thực hành số 5)
     * 1. Thực hiện cài thư viện nuget NSubstitute cho project MISA.UT.StubMock.App2.Test
     * 2. Thực hiện viết class NSubsLogAnalyzerTest => Test các class LogAnalyzerStubMock
     * => Mục đích cho thành viên nhóm hiểu về việc sử dụng framework NSubstitute thay thế cho việc
     * tạo stub lẫn mock thủ công như bài thực hành số 4.
     */
    public class Program
    {
        static void Main(string[] args)
        {
            var webService = new MISAWebService();
            var logAnMock = new LogAnalyzerMock(webService);
            logAnMock.Analyze("a.txt");

            var emailService = new MISAEmailService();
            var logAnStubMock = new LogAnalyzerStubMock(webService, emailService);
            logAnStubMock.Analyze("pass");

            Console.ReadLine();
        }
    }
}
