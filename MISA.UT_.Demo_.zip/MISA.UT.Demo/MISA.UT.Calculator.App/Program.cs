﻿using System;

namespace MISA.UT.Calculator.App
{
    /*
     * Sử dụng cho slide tổng quan về Unit Test (Thưc hành số 1)
     * Mục đích: Để cho thành viên buổi đào tạo hiểu cơ bản về unit test thông qua các thực hành cơ bản.
     * Kịch bản
     * 1. Cho thành viên buổi đào tạo thực hiện chạy thử chương trình.
     * 2. Tạo project MISA.UT.Calculator.App2.Test (Tương ứng với project MISA.UT.Calculator.App.Test)
     * 3. Yêu cầu thành viên viết thêm test case cho các method của class Calculator.
     * 4. Tiến hành viết thêm test case để cải tiến hàm Division.
     * => Mục đích để mọi người hiểu cơ bản về các viết test case.
     */
    public class Program
    {
        static void Main(string[] args)
        {
            var calculator = new Calculator();
            var sumValue = calculator.Add(1, 2).ToString();
            Console.WriteLine($"sumValue: {sumValue}");
            Console.ReadLine();
        }
    }
}
