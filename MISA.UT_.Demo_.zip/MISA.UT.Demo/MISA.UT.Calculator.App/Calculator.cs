﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.UT.Calculator.App
{
    
    public class Calculator
    {
        //Value - based
        public int Add(int x, int y)
        {
            return x + y;
        }

        public int Subtract(int x, int y)
        {
            return x - y;
        }

        public int Division(int x, int y)
        {
            return x / y;
        }

        //TODO Mở comment để demo từng bước refactor hàm theo test case của unit test
        //public int? Division(int x, int y)
        //{
        //    if (y == 0)
        //        return null;
        //    return x / y;
        //}

        //public decimal? Division(decimal x, decimal y)
        //{
        //    if (y == 0)
        //        return null;
        //    return x / y;
        //}

        //Interaction based
        public void DoubeValue(ref int x)
        {
            x = x + x;
        }
    }
}
