using NSubstitute;
using NUnit.Framework;

namespace MISA.UT.Refactor.AccessModifiers.App
{
    public class EmployeeRefactor2Test
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void GetSalary_CalculatorSlary_returnSalary()
        {
            //Arrange
            var salaryUtilityMock = Substitute.For<ISalaryUtility>();
            var employeeRefactor2 = new EmployeeRefactor2(salaryUtilityMock);
            salaryUtilityMock.CalculatorSalary(Arg.Any<float>(), Arg.Any<float>()).Returns((double)20000);
           
            //Act
            var result = employeeRefactor2.GetSalary();

            //Assert
            Assert.That(result, Is.EqualTo(20000));

        }
    }
}