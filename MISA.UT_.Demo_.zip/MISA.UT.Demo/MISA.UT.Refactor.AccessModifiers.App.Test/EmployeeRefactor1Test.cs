using NSubstitute;
using NUnit.Framework;

namespace MISA.UT.Refactor.AccessModifiers.App.Test
{
    public class EmployeeRefactor1Test
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void GetSalary_CalculatorSlary_returnSalary()
        {
            //Arrange
            var employeeRefactor1Fake = Substitute.For<EmployeeRefactor1>();
            employeeRefactor1Fake.GetType().GetMethod("CalculatorSalary", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance).
                Invoke(employeeRefactor1Fake, new object[] { }).Returns((double)10000);
            //Act
            var result = employeeRefactor1Fake.GetSalary();

            //Assert
            Assert.That(result, Is.EqualTo(10000));

        }
    }
}