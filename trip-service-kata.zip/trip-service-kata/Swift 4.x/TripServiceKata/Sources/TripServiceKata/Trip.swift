import Foundation

class Trip { }
