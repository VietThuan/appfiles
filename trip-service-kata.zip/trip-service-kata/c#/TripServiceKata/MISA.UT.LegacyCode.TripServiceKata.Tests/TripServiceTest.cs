﻿using MISA.UT.LegacyCode.TripServiceKata.Exception;
using MISA.UT.LegacyCode.TripServiceKata.Trip;
using NUnit.Framework;
using System.Collections.Generic;

namespace MISA.UT.LegacyCode.TripServiceKata.Tests
{
    public class TripServiceTest
    {
        private readonly User.User GUEST = null;
        private readonly User.User UNUSED_USER = null;
        private readonly User.User REGISTERED_USER = new User.User();
        private readonly User.User ANOTHER_USER = new User.User();
        private readonly Trip.Trip TO_VIETNAM = new Trip.Trip();
        private readonly Trip.Trip TO_LAOS = new Trip.Trip();
        private static User.User loggedInUser;
        private TestableTripService tripService;

        [SetUp]
        public void Init()
        {
            tripService = new TestableTripService();
            loggedInUser = REGISTERED_USER;
        }

        [Test]
        public void GetTripsByUser_UserIsNotLoggedIn_ThrowAnException()
        {
            //Arrange
            loggedInUser = GUEST;

            //Act and Assert
            Assert.Throws<UserNotLoggedInException>(() => tripService.GetTripsByUser(UNUSED_USER));
        }

        [Test]
        public void GetTripsByUser_UserAreNotFriends_ReturnAnyTrips()
        {
            //Arrange
            var friend = UserBuilder.Instance()
                .FriendsWith(ANOTHER_USER)
                .WithTrips(TO_VIETNAM)
                .Build();

            //Act
            var friendTrips = tripService.GetTripsByUser(friend);

            //Assert
            Assert.That(friendTrips.Count, Is.EqualTo(0));
        }

        [Test]
        public void GetTripsByUser_UsersAreFriends_ReturnFriendTrips()
        {
            //Arrange
            var friend = UserBuilder.Instance()
                .FriendsWith(new List<User.User>() { ANOTHER_USER, loggedInUser })
                .WithTrips(new List<Trip.Trip>() { TO_VIETNAM, TO_LAOS })
                .Build();

            //Act
            var friendTrips = tripService.GetTripsByUser(friend);

            //Assert
            Assert.That(friendTrips.Count, Is.EqualTo(2));
        }
                
        private class TestableTripService : TripService
        {
            protected override User.User GetLoggedInUser()
            {
                return loggedInUser;
            }

            protected override List<Trip.Trip> TripBy(User.User user)
            {
                return user.Trips();
            }
        }
    }
}
