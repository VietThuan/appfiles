﻿using System.Collections.Generic;

namespace MISA.UT.LegacyCode.TripServiceKata.Tests
{
    public class UserBuilder
    {
        private static UserBuilder instance = null;
        private List<User.User> users = new List<User.User>();
        private List<Trip.Trip> trips = new List<Trip.Trip>();
        private UserBuilder() { }
        public static UserBuilder Instance()
        {
            return instance ?? new UserBuilder();
        }

        public UserBuilder FriendsWith(List<User.User> users)
        {
            this.users = users;
            return this;
        }

        public UserBuilder FriendsWith(User.User user)
        {
            this.users = new List<User.User>() { user };
            return this;
        }

        public UserBuilder WithTrips(List<Trip.Trip> trips)
        {
            this.trips = trips;
            return this;
        }
        public UserBuilder WithTrips(Trip.Trip trip)
        {
            this.trips = new List<Trip.Trip>() { trip };
            return this;
        }

        public User.User Build()
        {
            var user = new User.User();
            AddTripTo(user);
            AddFriendTo(user);
            return user;
        }

        private void AddFriendTo(User.User user)
        {
            foreach (var friend in users)
            {
                user.AddFriend(friend);
            }
        }

        private void AddTripTo(User.User user)
        {
            foreach (var trip in trips)
            {
                user.AddTrip(trip);
            }
        }
    }

}
