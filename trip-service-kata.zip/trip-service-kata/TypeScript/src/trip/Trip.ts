export default class Trip {}
