
class Trip:
  pass
