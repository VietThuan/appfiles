
class UserNotLoggedInException(Exception):
  pass

