

class DependendClassCallDuringUnitTestException(Exception):
  pass


