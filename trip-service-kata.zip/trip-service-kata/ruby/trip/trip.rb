class Trip
end