class UserNotLoggedInException < StandardError

end