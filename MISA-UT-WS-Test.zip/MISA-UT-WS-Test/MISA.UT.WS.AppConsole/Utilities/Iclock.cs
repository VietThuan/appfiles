﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.UT.WS.AppConsole.Utilities
{
    public interface IClock
    {
        DateTime Now { get;}
    }
}
