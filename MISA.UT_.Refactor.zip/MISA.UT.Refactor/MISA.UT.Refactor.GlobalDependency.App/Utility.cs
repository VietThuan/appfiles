﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.UT.Refactor.GlobalDependency.App
{

    public interface IUtility
    {
        void UtilityMethod1();
        string UtilityMethod2(string value);
    }

    public class Utility : IUtility
    {
        private static IUtility utility;

        private Utility()
        {

        }

        public static IUtility Instance()
        {
            return utility ?? new Utility();
        }

        [Obsolete("Test only", true)]
        public static void SetInstance(IUtility fakeInstance)
        {
            utility = fakeInstance;
        }

        public void UtilityMethod1()
        {
            Console.WriteLine("Utility Method 1 called!");
        }

        public string UtilityMethod2(string value)
        {
            Console.WriteLine("Utility Method 2 called!");
            return string.Empty;
        }
    }
}
