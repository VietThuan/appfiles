﻿using System;

namespace MISA.UT.Refactor.GlobalDependency.App
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Refactor Utility
            Utility.Instance().UtilityMethod1();
            Utility.Instance().UtilityMethod2("Hello World");

            //Refactor Datetime
            Console.WriteLine(SystemTime.Instance().Now());

            Console.ReadLine();
        }
    }
}
