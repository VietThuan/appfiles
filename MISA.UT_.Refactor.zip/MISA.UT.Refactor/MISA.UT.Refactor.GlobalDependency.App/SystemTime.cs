﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.UT.Refactor.GlobalDependency.App
{
    public interface ISystemTime
    {
        DateTime Now();
    }

    public class SystemTime : ISystemTime
    {
        private static ISystemTime systemTime;
        private SystemTime() { }
        public static ISystemTime Instance()
        {
            return systemTime ?? new SystemTime();
        }

        [Obsolete("Test only", true)]
        public static void SetInstance(ISystemTime fakeInstance)
        {
            systemTime = fakeInstance;
        }
        public DateTime Now()
        {
            return DateTime.Now;
        }
    }
}
